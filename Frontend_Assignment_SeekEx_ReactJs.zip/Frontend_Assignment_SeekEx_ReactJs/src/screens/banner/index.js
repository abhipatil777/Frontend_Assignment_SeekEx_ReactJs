import React from 'react'
import './banner.css'
const Banner = () => {
    return (
        <section className='banner'/>
    )
}

export default Banner